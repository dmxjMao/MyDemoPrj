
// TreeSortDemoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TreeSortDemo.h"
#include "TreeSortDemoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CTreeSortDemoDlg dialog




CTreeSortDemoDlg::CTreeSortDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTreeSortDemoDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTreeSortDemoDlg::DoDataExchange(CDataExchange* pDX)
{
   CDialog::DoDataExchange(pDX);
   DDX_Control(pDX, IDC_TREE, m_tree);
}

BEGIN_MESSAGE_MAP(CTreeSortDemoDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
   ON_BN_CLICKED(IDC_BUTTON_GENERATE, &CTreeSortDemoDlg::OnBnClickedButtonGenerate)
   ON_BN_CLICKED(IDC_BUTTON_SORT, &CTreeSortDemoDlg::OnBnClickedButtonSort)
   ON_BN_CLICKED(IDC_BUTTON_SORTCUSTOM, &CTreeSortDemoDlg::OnBnClickedButtonSortcustom)
   ON_BN_CLICKED(IDC_BUTTON_SORTSELECTED, &CTreeSortDemoDlg::OnBnClickedButtonSortselected)
   ON_BN_CLICKED(IDC_BUTTON_SORTCUSTOMSELECTED, &CTreeSortDemoDlg::OnBnClickedButtonSortcustomselected)
END_MESSAGE_MAP()


// CTreeSortDemoDlg message handlers

BOOL CTreeSortDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTreeSortDemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTreeSortDemoDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTreeSortDemoDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CTreeSortDemoDlg::OnBnClickedButtonGenerate()
{
   DeleteContent();

   GenerateContent();
}

void CTreeSortDemoDlg::OnBnClickedButtonSort()
{
   SortItem(TVI_ROOT);
}

void CTreeSortDemoDlg::OnBnClickedButtonSortselected()
{
   HTREEITEM item = m_tree.GetSelectedItem();
   m_tree.SortChildren(item);
}

void CTreeSortDemoDlg::OnBnClickedButtonSortcustom()
{
   CustomSortItem(TVI_ROOT);
}

void CTreeSortDemoDlg::OnBnClickedButtonSortcustomselected()
{
   TVSORTCB tvs;

   tvs.hParent = m_tree.GetSelectedItem();
   tvs.lpfnCompare = CustomCompare;
   tvs.lParam = reinterpret_cast<LPARAM>(&m_tree);

   m_tree.SortChildrenCB(&tvs);
}

void CTreeSortDemoDlg::DeleteContent()
{
   m_tree.DeleteAllItems();

   for(std::vector<ItemData*>::iterator it = m_data.begin();
       it != m_data.end(); ++it)
   {
      if(*it != NULL)
         delete *it;
   }

   m_data.clear();
}

void CTreeSortDemoDlg::GenerateContent()
{
   for(int i = 0; i < 3; ++i)
   {
      HTREEITEM item = MakeItem(_T('A'), TVI_ROOT);

      for(int i = 0; i < 5; ++i)
      {
         MakeItem(_T('0'), item);
      }      

      m_tree.Expand(item, TVE_EXPAND);
   }   
}

ItemData* CTreeSortDemoDlg::MakeData(TCHAR base, TCHAR prefix)
{
   ItemData* data = new ItemData;

   if(prefix == 0)
      data->Name.Format(_T("%c"), base + rand()%10);
   else
      data->Name.Format(_T("%c%c"), prefix, base + rand()%10);

   data->Value = 10 + rand() % 90;

   m_data.push_back(data);

   return data;
}

HTREEITEM CTreeSortDemoDlg::MakeItem(TCHAR base, HTREEITEM parent)
{
   TCHAR prefix = _T('');
   if(parent != TVI_ROOT)
   {
      CString text = m_tree.GetItemText(parent);
      if(text.GetLength() > 0)
         prefix = text.GetAt(0);
   }
   ItemData* data = MakeData(base, prefix);
   HTREEITEM item = m_tree.InsertItem(data->ToString(), parent);
   m_tree.SetItemData(item, (DWORD_PTR)data);

   return item;
}
BOOL CTreeSortDemoDlg::DestroyWindow()
{
   DeleteContent();

   return CDialog::DestroyWindow();
}

void CTreeSortDemoDlg::SortItem(HTREEITEM item)
{
   if(item != NULL)
   {
      if(item == TVI_ROOT || m_tree.ItemHasChildren(item))
      {
         HTREEITEM child = m_tree.GetChildItem(item);

         while(child != NULL)
         {
            SortItem(child);
            child = m_tree.GetNextItem(child, TVGN_NEXT);
         }

         m_tree.SortChildren(item);
      }
   }
}

void CTreeSortDemoDlg::CustomSortItem(HTREEITEM item)
{
   if(item != NULL)
   {
      if(item == TVI_ROOT || m_tree.ItemHasChildren(item))
      {
         HTREEITEM child = m_tree.GetChildItem(item);

         while(child != NULL)
         {
            CustomSortItem(child);
            child = m_tree.GetNextItem(child, TVGN_NEXT);
         }

         TVSORTCB tvs;

         tvs.hParent = item;
         tvs.lpfnCompare = &CTreeSortDemoDlg::CustomCompare;
         tvs.lParam = reinterpret_cast<LPARAM>(&m_tree);

         m_tree.SortChildrenCB(&tvs);
      }
   }
}

int CALLBACK CTreeSortDemoDlg::CustomCompare(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort)
{
   ItemData* data1 = reinterpret_cast<ItemData*>(lParam1);
   ItemData* data2 = reinterpret_cast<ItemData*>(lParam2);
   CTreeCtrl* tree = reinterpret_cast<CTreeCtrl*>(lParamSort);

   return (data1 != NULL && data2 != NULL) ? (data1->Value > data2->Value) : 0;
}

