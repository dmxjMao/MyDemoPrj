
// TreeSortDemoDlg.h : header file
//

#pragma once
#include "afxcmn.h"
#include <vector>

struct ItemData
{
   CString  Name;
   int      Value;

   CString ToString() const
   {
      CString str;
      str.Format(_T("%s = %d"), Name, Value);
      return str;
   }
};

// CTreeSortDemoDlg dialog
class CTreeSortDemoDlg : public CDialog
{
// Construction
public:
	CTreeSortDemoDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_TREESORTDEMO_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
   virtual BOOL DestroyWindow();

   DECLARE_MESSAGE_MAP()

   afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
   afx_msg void OnBnClickedButtonGenerate();
   afx_msg void OnBnClickedButtonSort();
   afx_msg void OnBnClickedButtonSortcustom();
   afx_msg void OnBnClickedButtonSortselected();
   afx_msg void OnBnClickedButtonSortcustomselected();

private:
   CTreeCtrl m_tree;
   std::vector<ItemData*> m_data;

   void DeleteContent();
   void GenerateContent();
   ItemData* MakeData(TCHAR base, TCHAR prefix = _T(''));
   HTREEITEM MakeItem(TCHAR base, HTREEITEM parent);

   void SortItem(HTREEITEM item);
   void CustomSortItem(HTREEITEM item);

   static int CALLBACK CustomCompare(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort);
};
