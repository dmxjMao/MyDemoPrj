// ListCtrl_Category_Groups.h : main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols


// CListCtrl_Category_GroupsApp:
// See ListCtrl_Category_Groups.cpp for the implementation of this class
//

class CListCtrl_Category_GroupsApp : public CWinApp
{
public:
	CListCtrl_Category_GroupsApp();

// Overrides
	public:
	virtual BOOL InitInstance();

// Implementation

	DECLARE_MESSAGE_MAP()
};

extern CListCtrl_Category_GroupsApp theApp;